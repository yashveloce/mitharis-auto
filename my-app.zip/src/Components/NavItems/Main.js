import React from 'react'

export default function Main() {
    return (
        <div>
            <h2>Home</h2>
        </div>
    )
}
