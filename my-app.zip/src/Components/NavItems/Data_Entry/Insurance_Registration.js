import React from 'react'

export default function Insurance_Registration() {
    return (
        <div>
            
        </div>
    )
}
