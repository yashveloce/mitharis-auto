import React from 'react'

export default function Vehicle_Registration() {
    return (
        <div>
            
        </div>
    )
}
