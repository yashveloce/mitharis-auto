import React from 'react'

export default function Stolen() {
    return (
        <div>
            
        </div>
    )
}
