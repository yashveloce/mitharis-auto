import React from 'react'

export default function Enquiry_Generation() {
    return (
        <div>
            
        </div>
    )
}
