import React from 'react'

export default function Sales_Report() {
    return (
        <div>
            
        </div>
    )
}
